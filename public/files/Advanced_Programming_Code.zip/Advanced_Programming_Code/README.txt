Run the program using PyCharm (or equivalent) from main.py

Alternatively, the program can by run using Jupyter notebook from main.ipynb

Upon first launch, the user will be informed that they need to import data
which can be achieved by pressing the 'Import data from csvs' button in the
main window. These are the 'TxAntennaDAB.json' and 'TxParamsDAB.json' files
within this directory.